<?php $__env->startSection('content'); ?>
    <div class="pl-3 pt-4">
        <div class="pb-3">
            <div class="col">
                <form action="<?php echo e(route('warranty.edit.detail', $Warranty->tblitemwarranty_id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="action" value="create">
                    <div class="mb-3">
                        <label for="category-code" class="col-form-label">Kode Kategori :</label>
                        <select class="form-control" name="categorycode" id="category-code">
                            
                            <?php $__currentLoopData = $codeCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->tblitemcategory_id); ?>"
                                    <?php echo e($Warranty->tblitemcategory_id == $key ? 'selected' : ''); ?>>
                                    <?php echo e($row->tblitemcategory_code); ?> -
                                    <?php echo e($row->tblitemcategory_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="brand-code" class="col-form-label">Kode Merek :</label>
                        <select class="form-control" name="brandcode" id="brand-code">
                            
                            <?php $__currentLoopData = $codeBrand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->tblitembrand_id); ?>"
                                    <?php echo e($Warranty->tblitembrand_id == $key ? 'selected' : ''); ?>>
                                    <?php echo e($row->tblitembrand_code); ?> -
                                    <?php echo e($row->tblitembrand_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="model-code" class="col-form-label">Kode Model :</label>
                        <select class="form-control" style="width: 100%" name="modelcode" id="model-code">
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="sn-transaction" class="col-form-label">SN :</label>
                        <input type="text" class="form-control" name="sntransaction" id="sn-transaction"
                            value="<?php echo e(old('sntransaction', $Warranty->tblitemwarrant_SN)); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="dok-bukti" class="col-form-label">Dokumen Bukti :</label>
                        <input type="text" class="form-control" name="dokbukti" id="dok-bukti"
                            value="<?php echo e(old('dokbukti', $Warranty->tblitemwarrant_dokBukti)); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="distributor-id" class="col-form-label">Distributor :</label>
                        <input type="text" class="form-control" name="distributorname" id="distributor-id"
                            value="<?php echo e(old('distributorname', $Warranty->tblitemwarrant_distributor)); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="pemakai-id" class="col-form-label">Pemakai :</label>
                        <input type="text" class="form-control" name="pemakainame" id="pemakai-id"
                            value="<?php echo e(old('pemakainame', $Warranty->tblitemwarrant_username)); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="lokasi-id" class="col-form-label">Lokasi :</label>
                        <input type="text" class="form-control" name="lokasiname" id="lokasi-id"
                            value="<?php echo e(old('lokasiname', $Warranty->tblitemwarrant_location)); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="tanggal-beli-id" class="col-form-label">Tanggal Pembelian : </label>

                        <input type="date" class="form-control" name="tanggalbeliname"
                            value="<?php echo e(old('tanggalbeliname', date('Y-m-d'))); ?>" id="tanggal-beli-id">
                        <p><?php echo e($Warranty->tblitemwarrant_purchaseDate); ?></p>
                    </div>
                    <div class="mb-3">
                        <label for="period-id" class="col-form-label">Periode Bulan :</label>
                        <input type="number" class="form-control" min="1"
                            value="<?php echo e(old('periodname', $Warranty->tblitemwarrant_purchaseDate)); ?>" max="100"
                            name="periodname" id="period-id">
                    </div>
                    <div class="mb-3">
                        <label for="status-id" class="col-form-label">Status :</label>
                        <select class="form-control" name="statusname" id="status-id">
                            <?php $__currentLoopData = $codeStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->tblitemstatus_id); ?>"><?php echo e($row->tblitemstatus_name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="catatan-id" class="col-form-label">Catatan :</label>
                        <textarea class="form-control" name="note" id="model-name-add" form="AddForm"></textarea>
                    </div>

                    <?php if($errors->any() && old('action') == 'create'): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <button type="submit" id="submitbtn" class="btn btn-primary"><?php echo e(__('Simpan')); ?></button>
                    <a href="<?php echo e(route('warranty')); ?>">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Tutup')); ?></button>
                    </a>

                </form>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('#model-code').select2({
                placeholder: 'Select an Model'
            });
        });

        function matchCustom(params, data) {
            // If there are no search terms, return all of the data
            if ($.trim(params.term) === '') {
                return data;
            }

            // Do not display the item if there is no 'text' property
            if (typeof data.text === 'undefined') {
                return null;
            }

            // `params.term` should be the term that is used for searching
            // `data.text` is the text that is displayed for the data object
            var lowerData = data.text.toLowerCase();
            params.term = params.term.toLowerCase();
            if (lowerData.indexOf(params.term) > -1) {
                var modifiedData = $.extend({}, data, true);
                modifiedData.text += ' (matched)';


                // You can return modified objects from here
                // This includes matching the `children` how you want in nested data sets
                return modifiedData;
            }

            // Return `null` if the term should not be displayed
            return null;
        }
        $('#brand-code').on('change', function(e) {
            var brandCode = $(this).val();
            var categoryCode = $('#category-code').val();
            var urlWarrantyGetModel = "<?php echo e(route('warranty.getmodel')); ?>";
            $("#model-code").empty();
            $.ajax({
                url: urlWarrantyGetModel,
                data: {
                    "CategoryCode": categoryCode,
                    "BrandCode": brandCode
                },
                method: "GET",
                success: function(data) {
                    console.log(JSON.parse(data));
                    $("#model-code").select2({
                        data: JSON.parse(data),
                        minimumInputLength: 3,
                        matcher: matchCustom,
                        dropdownParent: $("#createModal")
                    });
                },
                error: function(err) {
                    console.log(err);
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>