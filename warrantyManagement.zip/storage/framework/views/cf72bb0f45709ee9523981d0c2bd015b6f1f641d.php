<?php $__env->startSection('title'); ?>
Home
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="container-fluid">
        <div class="col">
            <div class="row">
                <div class="col-sm py-4">
                    <i class="fas fa-briefcase-medical blackcolor fa-6x"></i>
                </div>
            </div>
            <div class="row">
                <div class="col-sm">
                    <p class="title">Warranty Management</p>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="line"></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\warrantyManagement\resources\views/welcome.blade.php ENDPATH**/ ?>