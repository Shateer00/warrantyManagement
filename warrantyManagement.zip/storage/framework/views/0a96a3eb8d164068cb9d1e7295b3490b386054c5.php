<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>List Merek Barang</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
        <!-- Styles -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    </head>
    <body>


        <nav class="navbar navbar-expand-lg navbar-light bg-primary">
            <a class="navbar-brand" href="#">Management Garansi</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
              <div class="navbar-nav">
                <a class="nav-item nav-link active" href="/">Home</a>
                <a class="nav-item nav-link" href="/brand/">Master Merek</a>
                <a class="nav-item nav-link" href="/category/">Master Kategori</a>
                <a class="nav-item nav-link" href="/model/">Master Model</a>
                <a class="nav-item nav-link" href="/transaction/">Transaksi Garansi</a>
              </div>
            </div>
          </nav>



        <div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">
            <div class="row">
              <div class="col-sm">
                <div class="px-3">
                    <main class="px-3">
                        <h1>By Santo Tech.</h1>
                      </main>
                </div>
              </div>
              <div class="col-sm">
              </div>
            </div>
          </div>

    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Edit Merek Barang</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <form action="/brand/edit/" method="POST" id="EditForm">
                <?php echo e(csrf_field()); ?>

                <div class="mb-3">
                    <label for="brand-code" class="col-form-label">Kode Merek :</label>
                    <input type ="hidden" name ="action" value="edit" >
                    <input type="text" class="form-control" id="brand-code-edit" name="brandcode" value="<?php echo e(old('brandcode')); ?>">

                  </div>
                  <div class="mb-3">
                    <label for="brand-name" class="col-form-label">Nama Merek :</label>

                    <input type="text" class="form-control" id="brand-name-edit" name="brandname" value="<?php echo e(old('brandname')); ?>">


                  </div>
                  <?php if($errors->any() && old('action') == 'edit'): ?>
                    <div class="alert alert-danger">
                        <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
            <div class="modal-footer">
              <button type="submit" id="submitbtn" class="btn btn-primary">Simpan</button>
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
            </form>
            </div>
          </div>
        </div>
      </div>


      <div class="modal fade" id="createModal" tabindex="-1" role="dialog" aria-labelledby="createModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Tambah Merek Barang</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <form action="/brand" method="POST" id="AddForm">
                <?php echo e(csrf_field()); ?>

                <div class="mb-3">
                    <label for="brand-code" class="col-form-label">Kode Merek :</label>
                    <input type ="hidden" name ="action" value="create" >
                    <input type="text" class="form-control" id="brand-code" name="brandcode" value="<?php echo e(old('brandcode')); ?>">

                  </div>
                  <div class="mb-3">
                    <label for="brand-name" class="col-form-label">Nama Merek :</label>

                    <input type="text" class="form-control" id="brand-name" name="brandname" value="<?php echo e(old('brandname')); ?>">


                  </div>
                  <?php if($errors->any() &&  old('action') == 'create'): ?>
                    <div class="alert alert-danger">
                        <ul>

                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
            <div class="modal-footer">
              <button type="submit" id="submitbtn" class="btn btn-primary">Simpan</button>
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
            </form>
            </div>
          </div>
        </div>
      </div>

      <script>
          <?php if(count($errors->all()) > 0 &&  old('action') == 'create') {?>
            $('#createModal').modal('show');
          <?php }?>

          <?php if(count($errors->all()) > 0  && old('action') == 'edit') {?>
            $('#editModal').modal('show');
          <?php }?>



            $(".buttonEditBrand").click(function() {
                var url = "/brand/edit/" + $(this).data('id');
                    $("#EditForm").attr("action", url);
                $('#brand-code-edit').val($(this).data('code'));
                $('#brand-name-edit').val($(this).data('name'));
            });
      </script>
    </body>
</html>
