<?php $__env->startSection('content'); ?>
    <div class="pl-3 pt-4">
        <div class="row">
            <div class="pb-3 col-12 col-md-8">
                <button type="button" id="buttonAddWarranty" class="btn btn-primary" data-toggle="modal"
                    data-target="#createModal" data-whatever="@mdo">Tambah Garansi</button>
            </div>
            <div class="col-12 col-md-4">
                <form class="form-inline my-2 my-lg-0" action="<?php echo e(route('warranty.search')); ?>" method="get">
                    <?php if($requestParam == ''): ?>
                        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search"
                            name='param'>
                    <?php else: ?>
                        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search"
                            name='param' value="<?php echo e($requestParam); ?>">
                    <?php endif; ?>
                    <button class="btn btn-success my-2 my-sm-0" type="submit">Search</button>
                    <a class="btn btn-warning my-2 my-sm-0 ml-3" href="<?php echo e(route('warranty')); ?>">Reset</a>
                </form>
            </div>
        </div>

        <div class="col-12">
            <h3>List Garansi Barang</h3>
            <table class="table table-hover table-responsive-sm">
                <thead>
                    <tr>
                        <th scope="col">
                            Nomor
                        </th>
                        <th scope="col">
                            SN
                        </th>
                        <th scope="col">
                            Kategori
                        </th>
                        <th scope="col">
                            Merek
                        </th>
                        <th scope="col">
                            Model
                        </th>
                        <th>
                            Sub Menu
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $Warranty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($Warranty->firstItem() + $key); ?>

                            </td>
                            <td>
                                <?php echo e($row->tblitemwarrant_SN); ?>

                            </td>
                            <td>

                                <?php echo e($row->tblitemcategory_code); ?> - <?php echo e($row->tblitemcategory_name); ?>

                            </td>
                            <td>

                                <?php echo e($row->tblitembrand_code); ?> - <?php echo e($row->tblitembrand_name); ?>

                            </td>
                            <td>
                                <?php echo e(Str::limit($row->tblitemmodel_codeModel . ' - ' . $row->tblitemmodel_descriptionModel, 30)); ?>

                            </td>
                            <td>
                                <a class="btn btn-primary" href="<?php echo e(route('warranty.edit', $row->tblitemwarranty_id)); ?>">
                                    <p class="fas fa-edit"></p>
                                    <p class="btnEdit">Edit</p>
                                </a>
                                

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <?php echo e($Warranty->links()); ?>

        </div>

    </div>


    

    

    <div class="modal fade" id="createModal" tabindex="-1" role="dialog" aria-labelledby="createModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Tambah Garansi</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('warranty.add')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">

                        <input type="hidden" name="action" value="create">
                        <div class="mb-3">
                            <label for="category-code" class="col-form-label">Kode Kategori :</label>
                            <select class="form-control" name="categorycode" id="category-code">
                                
                                <?php $__currentLoopData = $codeCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row->tblitemcategory_id); ?>"
                                        <?php echo e(old('categorycode') == $key ? 'selected' : ''); ?>>
                                        <?php echo e($row->tblitemcategory_code); ?> -
                                        <?php echo e($row->tblitemcategory_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="brand-code" class="col-form-label">Kode Merek :</label>
                            <select class="form-control" name="brandcode" id="brand-code">
                                
                                <?php $__currentLoopData = $codeBrand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row->tblitembrand_id); ?>"
                                        <?php echo e(old('brandcode') == $key ? 'selected' : ''); ?>>
                                        <?php echo e($row->tblitembrand_code); ?> -
                                        <?php echo e($row->tblitembrand_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="model-code" class="col-form-label">Kode Model :</label>
                            <select class="form-control" style="width: 100%" name="modelcode" id="model-code">
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="sn-transaction" class="col-form-label">SN :</label>
                            <input type="text" class="form-control" name="sntransaction" id="sn-transaction"
                                value="<?php echo e(old('sntransaction')); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="dok-bukti" class="col-form-label">Dokumen Bukti :</label>
                            <input type="text" class="form-control" name="dokbukti" id="dok-bukti"
                                value="<?php echo e(old('dokbukti')); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="distributor-id" class="col-form-label">Distributor :</label>
                            <input type="text" class="form-control" name="distributorname" id="distributor-id"
                                value="<?php echo e(old('distributorname')); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="pemakai-id" class="col-form-label">Pemakai :</label>
                            <input type="text" class="form-control" name="pemakainame" id="pemakai-id"
                                value="<?php echo e(old('pemakainame')); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="lokasi-id" class="col-form-label">Lokasi :</label>
                            <input type="text" class="form-control" name="lokasiname" id="lokasi-id"
                                value="<?php echo e(old('lokasiname')); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="tanggal-beli-id" class="col-form-label">Tanggal Pembelian :</label>
                            <input type="date" class="form-control" name="tanggalbeliname"
                                value="<?php echo e(old('tanggalbeliname', date('Y-m-d'))); ?>" id="tanggal-beli-id">
                        </div>
                        <div class="mb-3">
                            <label for="period-id" class="col-form-label">Periode Bulan :</label>
                            <input type="number" class="form-control" min="1" value="<?php echo e(old('periodname')); ?>" max="100"
                                name="periodname" id="period-id">
                        </div>
                        <div class="mb-3">
                            <label for="status-id" class="col-form-label">Status :</label>
                            <select class="form-control" name="statusname" id="status-id">
                                <?php $__currentLoopData = $codeStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row->tblitemstatus_id); ?>"><?php echo e($row->tblitemstatus_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="catatan-id" class="col-form-label">Catatan :</label>
                            <textarea name="note" class="form-control" id="note-id"><?php echo e(old('note')); ?></textarea>
                            <div class="mb-3">
                            </div>

                            <?php if($errors->any() && old('action') == 'create'): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" id="submitbtn" class="btn btn-primary">Simpan</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                        </div>
                </form>
            </div>
        </div>
    </div>


    <script>
        $(document).ready(function() {
            $('#model-code').select2({
                placeholder: 'Select an Model'
            });
        });

        function matchCustom(params, data) {
            // If there are no search terms, return all of the data
            if ($.trim(params.term) === '') {
                return data;
            }

            // Do not display the item if there is no 'text' property
            if (typeof data.text === 'undefined') {
                return null;
            }

            // `params.term` should be the term that is used for searching
            // `data.text` is the text that is displayed for the data object
            var lowerData = data.text.toLowerCase();
            params.term = params.term.toLowerCase();
            if (lowerData.indexOf(params.term) > -1) {
                var modifiedData = $.extend({}, data, true);
                modifiedData.text += ' (matched)';


                // You can return modified objects from here
                // This includes matching the `children` how you want in nested data sets
                return modifiedData;
            }

            // Return `null` if the term should not be displayed
            return null;
        }
        $('#brand-code').on('change', function(e) {
            var brandCode = $(this).val();
            var categoryCode = $('#category-code').val();
            var urlWarrantyGetModel = "<?php echo e(route('warranty.getmodel')); ?>";
            $("#model-code").empty();
            $.ajax({
                url: urlWarrantyGetModel,
                data: {
                    "CategoryCode": categoryCode,
                    "BrandCode": brandCode
                },
                method: "GET",
                success: function(data) {
                    console.log(JSON.parse(data));
                    $("#model-code").select2({
                        data: JSON.parse(data),
                        minimumInputLength: 3,
                        matcher: matchCustom,
                        dropdownParent: $("#createModal")
                    });
                },
                error: function(err) {
                    console.log(err);
                }
            });
        });
        <?php
        // if (count($errors->all()) > 0 && old('action') == 'create') {
        //     echo "$('#createModal').modal('show');";
        // }
        //
        ?>
        <?php
        // if (count($errors->all()) > 0 && old('action') == 'edit') {
        //     echo "$('#editModal').modal('show');";
        // }
        //
        ?>
        // $(".buttonViewModel").click(function() {
        //     $('#model-code-view').val($(this).data('modelid')).change();
        //     $('#dok-bukti-view').val($(this).data('dokbukti'));
        //     $('#distributor-id-view').val($(this).data('distributor'));
        //     $('#sn-transaction-view').val($(this).data('sn'));
        //     $('#pemakai-id-view').val($(this).data('user'));
        //     $('#lokasi-id-view').val($(this).data('location'));
        //     $('#tanggal-beli-id-view').val($(this).data('purchasedate').substring(0, 10));
        //     $('#period-id-view').val($(this).data('periodmonth'));
        //     $('#model-note-view').val($(this).data('note'));
        //     $('#status-id-view').val($(this).data('status'));
        //     var categorydetail = $(this).data('categorydetail');
        //     var branddetail = $(this).data('branddetail');
        //     var categoryCN = $(this).data('category');
        //     var brandCN = $(this).data('brand');
        //     $("#category-code-view").val(categorydetail).change();
        //     $("#brand-code-view").val(branddetail).change();
        // });
        // $(".buttonEditModel").click(function() {
        //     var url = "/transaction/edit/" + $(this).data('id');
        //     $("#EditForm").attr("action", url);
        //     $('#dok-bukti').val($(this).data('dokbukti'));
        //     $('#distributor-id').val($(this).data('distributor'));
        //     $('#sn-transaction').val($(this).data('sn'));
        //     $('#pemakai-id').val($(this).data('user'));
        //     $('#lokasi-id').val($(this).data('location'));
        //     $('#tanggal-beli-id').val($(this).data('purchasedate').substring(0, 10));
        //     $('#period-id').val($(this).data('periodmonth'));
        //     $('#model-note').val($(this).data('note'));
        //     $('#status-id').val($(this).data('status'));
        //     var categorydetail = $(this).data('categorydetail');
        //     var branddetail = $(this).data('branddetail');
        //     var categoryCN = $(this).data('category');
        //     var brandCN = $(this).data('brand');
        //     $("#category-code-edit").val(categorydetail).change();
        //     $("#brand-code-edit").val(branddetail).change();
        // });
        // $('select[name="categorycode"]').on('change', function() {
        //     Nyoba(this, "cat");
        //     // console.log('Ini Add');
        // });

        // $('select[name="brandcode"]').on('change', function() {
        //     Nyoba(this, "brand");
        //     // console.log('Ini Add');
        // });

        // $('select[name="categorycodeedit"]').on('change', function() {
        //     NyobaEdit(this, "cat");
        //     // console.log('Ini Edit');
        // });

        // $('select[name="brandcodeedit"]').on('change', function() {
        //     NyobaEdit(this, "brand");
        //     // console.log('Ini Edit');
        // });
    </script>

    <?php if(count($errors->all()) > 0 && old('action') == 'create'): ?>
        <script>
            ModalCreateShow();
        </script>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>