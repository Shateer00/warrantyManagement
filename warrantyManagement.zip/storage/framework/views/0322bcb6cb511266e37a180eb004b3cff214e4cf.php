<?php $__env->startSection('title'); ?>
Edit Kategori
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <form action="<?php echo e(route('category.edit.detail', $category->tblitemcategory_id)); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="form-floating mb-3">


                    <input type="text" class="form-control upperText" id="category-code" name="categorycode"
                        maxlength="4" for="category-code"
                        value="<?php echo e(old('categorycode', $category->tblitemcategory_code)); ?>" placeholder="Kode Kategori">
                    <label for="category-code"><?php echo e(__('Kode Kategori')); ?></label>
                    <input type="hidden" name="action" value="edit">
                </div>
                <div class="form-floating mb-3">

                    <input type="text" class="form-control" placeholder="Nama Kategori" for="category-name"
                        id="category-name" name="categoryname"
                        value=" <?php echo e(old('categoryname', $category->tblitemcategory_name)); ?>">

                    <label for="category-name"><?php echo e(__('Nama Kategori')); ?></label>

                </div>
                <?php if($errors->any() && old('action') == 'edit'): ?>
                <div class="alert alert-danger mb-4">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <button type="submit" id="submitbtn" class="btn btn-primary"><?php echo e(__('Simpan')); ?></button>
                <a href="<?php echo e(route('category')); ?>">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Tutup')); ?></button>
                </a>

            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\warrantyManagement\resources\views/category/edit.blade.php ENDPATH**/ ?>