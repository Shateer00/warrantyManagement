<?php $__env->startSection('content'); ?>
    <div class="pl-3 pt-4">
        <div class="pb-3">
            <div class="col">
                <form action="<?php echo e(route('model.edit.detail',$model->tblitemmodel_id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        
                        
                        <label for="category-code" class="col-form-label">Kode Kategori :</label>
                        <select class="form-control" name="categorycode" id="category-code">
                            <?php $__currentLoopData = $codeCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->tblitemcategory_id); ?>"
                                    <?php echo e($model->tblitemcategory_id == $key ? 'selected' : ''); ?>>
                                    <?php echo e($row->tblitemcategory_code); ?> -
                                    <?php echo e($row->tblitemcategory_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        
                        <label for="brand-code" class="col-form-label">Kode Merek :</label>
                        <select class="form-control" name="brandcode" id="brand-code">
                            <?php $__currentLoopData = $codeBrand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->tblitembrand_id); ?>"
                                    <?php echo e($model->tblitembrand_id == $key ? 'selected' : ''); ?>><?php echo e($row->tblitembrand_code); ?> -
                                    <?php echo e($row->tblitembrand_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>


                    </div>

                    <div class="mb-3">
                        <label for="model-code" class="col-form-label">Kode Model :</label>
                        <input type="hidden" name="action" value="create">
                        <input type="text" class="form-control upperText" id="model-code" name="modelcode"
                            value="<?php echo e(old('modelcode',$model->tblitemmodel_codeModel)); ?>">

                    </div>

                    <label for="model-name" class="col-form-label">Deskripsi Model :</label>

                    
                    <textarea name="modelname" class="form-control"
                        id="model-name"><?php echo e(old('modelname',$model->tblitemmodel_descriptionModel)); ?></textarea>
                    <div class="mb-3">

                    </div>
                    <?php if($errors->any() && old('action') == 'create'): ?>
                        <div class="alert alert-danger">
                            <ul>

                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <button type="submit" id="submitbtn" class="btn btn-primary"><?php echo e(__('Simpan')); ?></button>
                    <a href="<?php echo e(route('model')); ?>">
                    <button type="button" class="btn btn-secondary"  data-dismiss="modal"><?php echo e(__('Tutup')); ?></button>
                    </a>

                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>