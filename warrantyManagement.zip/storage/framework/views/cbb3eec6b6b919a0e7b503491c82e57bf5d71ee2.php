
<?php $__env->startSection('title'); ?>
Kategori
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="pl-3 pt-4 pr-3 pb-4">
    <div class="row">
        <div class="pt-3 pl-3 pb-3 col-md">
            <button type="button" id="buttonAddCategory" class="btn btn-dark" data-toggle="modal" data-backdrop="static"
                data-keyboard="false" data-target="#createModal" data-whatever="@mdo"><i
                    class="fas fa-plus"></i></button>
        </div>
        <div class="pt-3 pl-3 pb-3 col-md-4">
            <form class="form-inline my-2 my-lg-0" action="<?php echo e(route('category.search')); ?>" method="get">
                <?php if($requestParam == ''): ?>
                <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" name='param'>
                <?php else: ?>
                <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" name='param'
                    value="<?php echo e($requestParam); ?>">
                <?php endif; ?>
                <button class="btn btn-success my-2 my-sm-0" type="submit"><i class="fas fa-search"></i></button>
                <a class="btn btn-secondary my-2 my-sm-0 ml-3" href="<?php echo e(route('category')); ?>">Reset</a>
            </form>
        </div>
    </div>

    <div class="col-12">
        <h3 class="text-dark">List Kategori Barang</h3>
        <?php if(count($category) == 0): ?>
        <div class="align-items-center justify-content-center flex-row d-flex py-4">
            <div class="card bg-info flex-center">
                <div class="card-body EmptyTable">
                    <a class="text-white">Data Kategori belum ada / Tidak ditemukan</a>
                </div>
            </div>
        </div>
        <?php else: ?>
        <table class="table table-bordered" id="TheTable">
            <thead class="table-info">
                <tr>
                    <th scope="col" class="col-1" class="Oswald">
                        Nomor
                    </th>
                    <th scope="col" class="col-1" class="Oswald">
                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('tblitemcategory_code','Kode Kategori'));?>
                    </th>
                    <th scope="col" class="col-8" class="Oswald">
                        <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('tblitemcategory_name','Nama Kategori'));?>
                    </th>
                    <th scope="col" class="col-2" class="Oswald">
                        Sub Menu
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td data-label="Nomor" class="RowNumber Oswald">
                        <?php echo e($category->firstItem() + $key); ?>

                    </td>
                    <td data-label="Kode" class="Oswald">
                        <?php echo e($row->tblitemcategory_code); ?>

                    </td>
                    <td data-label="Kode" class="Oswald">
                        <?php echo e($row->tblitemcategory_name); ?>

                    </td>
                    <td class="text-center">
                        <a class="btn btn-primary" href="<?php echo e(route('category.edit', $row->tblitemcategory_id)); ?>">
                            <span class="btnEdit"><i class="fas fa-edit"></i>&nbsp;Edit</span>
                        </a>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo $category->appends(\Request::except('page'))->render(); ?>

        
        <?php endif; ?>
    </div>

</div>




<div class="modal fade" id="createModal" tabindex="-1" role="dialog" aria-labelledby="createModalLabel"
    aria-hidden="true" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Kategori Barang</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('category.add')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">

                    <div class="form-floating mb-3">
                        <input type="text" class="form-control upperText" id="category-code" name="categorycode"
                            maxlength="4" for="category-code" value="<?php echo e(old('categorycode')); ?>"
                            placeholder="Kode Kategori">

                        <label for="category-code">Kode Kategori</label>

                        <input type="hidden" name="action" value="create">

                    </div>
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" id="category-name" name="categoryname"
                            value="<?php echo e(old('categoryname')); ?>" for="category-name" placeholder="Nama Kategori">

                        <label for="category-name">Nama Kategori :</label>
                    </div>
                    <?php if($errors->any() && old('action') == 'create'): ?>
                    <div class="alert alert-danger mb-4">
                        <ul class="mb-0">

                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="submit" id="submitbtn" class="btn btn-primary">Simpan</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>

                </div>
            </form>
        </div>
    </div>
</div>

<?php if (isset($component)) { $__componentOriginal1f5c57b55f8d1eb1fd138fb074f42c06eafcdf04 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ErrorModal::class, []); ?>
<?php $component->withName('error-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
 <?php if (isset($__componentOriginal1f5c57b55f8d1eb1fd138fb074f42c06eafcdf04)): ?>
<?php $component = $__componentOriginal1f5c57b55f8d1eb1fd138fb074f42c06eafcdf04; ?>
<?php unset($__componentOriginal1f5c57b55f8d1eb1fd138fb074f42c06eafcdf04); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginal7ff3ff0edadcd8fa0808bd2a18d4b3d15dce37d4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SuccessModal::class, []); ?>
<?php $component->withName('success-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
 <?php if (isset($__componentOriginal7ff3ff0edadcd8fa0808bd2a18d4b3d15dce37d4)): ?>
<?php $component = $__componentOriginal7ff3ff0edadcd8fa0808bd2a18d4b3d15dce37d4; ?>
<?php unset($__componentOriginal7ff3ff0edadcd8fa0808bd2a18d4b3d15dce37d4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php if($errors->any() && old('action') == 'create'): ?>
ModalCreateShow();
<?php endif; ?>;
<?php if(Session::has('error')): ?>
ModalErrorShow();
<?php endif; ?>;
<?php if(Session::has('success')): ?>
ModalSuccessShow();
<?php endif; ?>;
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\warrantyManagement\resources\views/category/index.blade.php ENDPATH**/ ?>