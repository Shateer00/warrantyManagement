<?php $__env->startSection('title'); ?>
Edit Merek
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <form action="<?php echo e(route('brand.edit.detail', $brand->tblitembrand_id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control upperText" for="brand-code" id="brand-code" name="brandcode"
                        maxlength="4" value="<?php echo e(old('brandcode', $brand->tblitembrand_code)); ?>"
                        placeholder="Kode Merek">
                    <label for="brand-code">Kode Merek</label>

                    <input type="hidden" name="action" value="edit">
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" for="brand-name" id="brand-name" name="brandname"
                        value="<?php echo e(old('brandname', $brand->tblitembrand_name)); ?>" placeholder="Nama Merek">
                    <label for="brand-name">Nama Merek</label>
                </div>
                <?php if($errors->any() && old('action') == 'edit'): ?>
                <div class="alert alert-danger mb-4">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <button type="submit" id="submitbtn" class="btn btn-primary"><?php echo e(__('Simpan')); ?></button>
                <a href="<?php echo e(route('brand')); ?>">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Tutup')); ?></button>
                </a>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\warrantyManagement\resources\views/brand/edit.blade.php ENDPATH**/ ?>