<?php $__env->startSection('title'); ?>
Home
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <p class="font-weight-bold text-center mb-0">Summary Chart</p>
                </div>
                <div class=" border border-dark">
                    <canvas id="SummaryChart" width="100" height="100"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
const TheSummaryChart = document.getElementById('SummaryChart').getContext('2d');
CreateDashboardSummaryChart(
TheSummaryChart,
<?php echo e($totalBrand); ?>,
<?php echo e($totalCategory); ?>,
<?php echo e($totalModel); ?>,
<?php echo e($totalWarranty); ?>

);

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\warrantyManagement\resources\views/home.blade.php ENDPATH**/ ?>