<?php $__env->startSection('content'); ?>
    <div class="pl-3 pt-4">
        <div class="pb-3">
            <div class="col">
                <form action="<?php echo e(route('brand.edit.detail',$brand->tblitembrand_id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label for="brand-code" class="col-form-label"><?php echo e(__('Kode Merek :')); ?></label>
                        <input type="hidden" name="action" value="edit">
                        <input type="text" class="form-control Upper" id="brand-code" name="brandcode"
                            value="<?php echo e(old('brandcode',$brand->tblitembrand_code)); ?>">

                    </div>
                    <div class="mb-3">
                        <label for="brand-name" class="col-form-label"><?php echo e(__('Nama Merek :')); ?></label>

                        <input type="text" class="form-control" id="brand-name" name="brandname"
                            value=" <?php echo e(old('brandname',$brand->tblitembrand_name)); ?>">
                    </div>
                    <?php if($errors->any() && old('action') == 'edit'): ?>
                        <div class="alert alert-danger">
                            <ul>

                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <button type="submit" id="submitbtn" class="btn btn-primary"><?php echo e(__('Simpan')); ?></button>
                    <a href="<?php echo e(route('brand')); ?>">
                    <button type="button" class="btn btn-secondary"  data-dismiss="modal"><?php echo e(__('Tutup')); ?></button>
                    </a>

                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>