<?php $__env->startSection('content'); ?>
    <div class="pl-3 pt-4">
        <div class="pb-3">
            <div class="col">
                <form action="<?php echo e(route('category.edit.detail', $category->tblitemcategory_id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label for="category-code" class="col-form-label"><?php echo e(__('Kode Kategory :')); ?></label>
                        <input type="hidden" name="action" value="edit">
                        <input type="text" class="form-control Upper" id="category-code" name="categorycode"
                            value="<?php echo e(old('categorycode', $category->tblitemcategory_code)); ?>">

                    </div>
                    <div class="mb-3">
                        <label for="category-name" class="col-form-label"><?php echo e(__('Nama Kategori :')); ?></label>

                        <input type="text" class="form-control" id="category-name" name="categoryname"
                            value=" <?php echo e(old('categoryname', $category->tblitemcategory_name)); ?>">
                    </div>
                    <?php if($errors->any() && old('action') == 'edit'): ?>
                        <div class="alert alert-danger">
                            <ul>

                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <button type="submit" id="submitbtn" class="btn btn-primary"><?php echo e(__('Simpan')); ?></button>
                    <a href="<?php echo e(route('category')); ?>">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Tutup')); ?></button>
                    </a>

                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>