<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>List Transaksi </title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"
        integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
    <!-- Styles -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <script type="text/javascript" src="<?php echo e(asset('js/functions.js')); ?>"></script>
</head>

<body>


    <nav class="navbar navbar-expand-lg navbar-light bg-secondary">
        <a class="navbar-brand" href="#">Management Garansi</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup"
            aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <a class="nav-item nav-link" href="/">Home</a>
                <a class="nav-item nav-link" href="/brand/">Master Merek</a>
                <a class="nav-item nav-link" href="/category/">Master Kategori</a>
                <a class="nav-item nav-link" href="/model/">Master Model</a>
                <a class="nav-item nav-link active" href="/transaction/">Transaksi Garansi</a>
            </div>
        </div>
    </nav>


    <div class="pl-3 pt-4">
        <div class="row">
            <div class="pb-3 col-12 col-md-8">
                <button type="button" id="buttonAddcategory" class="btn btn-primary" data-toggle="modal"
                    data-target="#createModal" data-whatever="@mdo">Tambah Transaksi</button>
            </div>
            <div class="col-12 col-md-4">
                <form class="form-inline my-2 my-lg-0" action="/transaction/search" method="get">
                    <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search"
                        name='param'>
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                    <a class="btn btn-outline-warning my-2 my-sm-0 ml-3" href="/transaction">Reset</a>
                </form>
            </div>
        </div>

        <div class="col-12">
            <h3>List Warranty Barang</h3>
            <table class="table table-hover table-responsive-sm">
                <thead>
                    <tr>
                        <th scope="col">
                            Nomor
                        </th>
                        <th scope="col">
                            SN
                        </th>
                        <th scope="col">
                            Kategori
                        </th>
                        <th scope="col">
                            Merek
                        </th>
                        <th scope="col">
                            Model
                        </th>
                        <th>
                            Sub Menu
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $Warranty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($Warranty->firstItem() + $key); ?>

                            </td>
                            <td>
                                <?php echo e($row->tblitemwarrant_SN); ?>

                            </td>
                            <td>

                                <?php echo e($row->tblitemcategory_code); ?> - <?php echo e($row->tblitemcategory_name); ?>

                            </td>
                            <td>

                                <?php echo e($row->tblitembrand_code); ?> - <?php echo e($row->tblitembrand_name); ?>

                            </td>
                            <td>
                                <?php echo e($row->tblitemmodel_codeModel); ?> - <?php echo e($row->tblitemmodel_descriptionModel); ?>

                            </td>
                            <td>
                                <button type="button"
                                    data-id="<?php echo e($row->tblitemwarranty_id); ?>"
                                    data-modelid="<?php echo e($row->tblitemmodel_id); ?>"
                                    data-categorydetail="<?php echo e($row->tblitemcategory_id); ?>"
                                    data-branddetail="<?php echo e($row->tblitembrand_id); ?>"
                                    data-sn="<?php echo e($row->tblitemwarrant_SN); ?>"
                                    data-dokbukti="<?php echo e($row->tblitemwarrant_dokBukti); ?>"
                                    data-distributor="<?php echo e($row->tblitemwarrant_distributor); ?>"
                                    data-user="<?php echo e($row->tblitemwarrant_username); ?>"
                                    data-location="<?php echo e($row->tblitemwarrant_location); ?>"
                                    data-purchasedate="<?php echo e($row->tblitemwarrant_purchaseDate); ?>"
                                    data-periodmonth="<?php echo e($row->tblitemwarrant_monthPeriod); ?>"
                                    data-status="<?php echo e($row->tblitemstatus_id); ?>"
                                    data-note="<?php echo e($row->tblitemwarrant_note); ?>"
                                    class="btn btn-primary buttonViewModel" data-toggle="modal" data-target="#viewModal"
                                    data-whatever="@mdo">View</button>
                                <button type="button"
                                    data-id="<?php echo e($row->tblitemwarranty_id); ?>"
                                    data-categorydetail="<?php echo e($row->tblitemcategory_id); ?>"
                                    data-branddetail="<?php echo e($row->tblitembrand_id); ?>"
                                    data-sn="<?php echo e($row->tblitemwarrant_SN); ?>"
                                    data-dokbukti="<?php echo e($row->tblitemwarrant_dokBukti); ?>"
                                    data-distributor="<?php echo e($row->tblitemwarrant_distributor); ?>"
                                    data-user="<?php echo e($row->tblitemwarrant_username); ?>"
                                    data-location="<?php echo e($row->tblitemwarrant_location); ?>"
                                    data-purchasedate="<?php echo e($row->tblitemwarrant_purchaseDate); ?>"
                                    data-periodmonth="<?php echo e($row->tblitemwarrant_monthPeriod); ?>"
                                    data-status="<?php echo e($row->tblitemstatus_id); ?>"
                                    data-note="<?php echo e($row->tblitemwarrant_note); ?>"
                                    class="btn btn-primary buttonEditModel" data-toggle="modal" data-target="#editModal"
                                    data-whatever="@mdo">Edit</button>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <?php echo e($Warranty->links()); ?>

        </div>

    </div>


    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Transaksi</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="/transaction/edit/" method="POST" id="EditForm">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="action" value="edit">
                        <div class="mb-3">
                            <label for="category-code-edit" class="col-form-label">Kode Kategori :</label>
                            <select class="form-control" name="categorycodeedit" id="category-code-edit" >
                                <option value="">PILIH KODE KATEGORI</option>
                                <?php $__currentLoopData = $codeCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row->tblitemcategory_id); ?>">
                                        <?php echo e($row->tblitemcategory_code); ?> -
                                        <?php echo e($row->tblitemcategory_name); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="brand-code-edit" class="col-form-label">Kode Merek :</label>
                            <select class="form-control" name="brandcodeedit" id="brand-code-edit" >
                                <option value="">PILIH KODE MEREK</option>
                                <?php $__currentLoopData = $codeBrand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row->tblitembrand_id); ?>"><?php echo e($row->tblitembrand_code); ?> -
                                        <?php echo e($row->tblitembrand_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="model-code-edit" class="col-form-label">Kode Model :</label>
                            <select class="form-control" name="modelcodeedit" id="model-code-edit" >
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="sn-transaction" class="col-form-label">SN :</label>
                            <input type="text" class="form-control" name="sntransaction" id="sn-transaction">
                        </div>
                        <div class="mb-3">
                            <label for="dok-bukti" class="col-form-label">Dokumen Bukti :</label>
                            <input type="text" class="form-control" name="dokbukti" id="dok-bukti">
                        </div>
                        <div class="mb-3">
                            <label for="distributor-id" class="col-form-label">Distributor :</label>
                            <input type="text" class="form-control" name="distributorname" id="distributor-id">
                        </div>
                        <div class="mb-3">
                            <label for="pemakai-id" class="col-form-label">Pemakai :</label>
                            <input type="text" class="form-control" name="pemakainame" id="pemakai-id">
                        </div>
                        <div class="mb-3">
                            <label for="lokasi-id" class="col-form-label">Lokasi :</label>
                            <input type="text" class="form-control" name="lokasiname" id="lokasi-id">
                        </div>
                        <div class="mb-3">
                            <label for="tanggal-beli-id" class="col-form-label">Tanggal Pembelian :</label>
                            <input type="date" class="form-control" name="tanggalbeliname" id="tanggal-beli-id">
                        </div>
                        <div class="mb-3">
                            <label for="period-id" class="col-form-label">Periode Bulan :</label>
                            <input type="number" class="form-control" min="1" value="0" max="100" name="periodname"
                                id="period-id">
                        </div>
                        <div class="mb-3">
                            <label for="status-id" class="col-form-label">Status :</label>
                            <select class="form-control" name="statusname" id="status-id">
                                <?php $__currentLoopData = $codeStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row->tblitemstatus_id); ?>"><?php echo e($row->tblitemstatus_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="catatan-id" class="col-form-label">Catatan :</label>
                            <textarea class="form-control" name="note" id="model-note" form="EditForm"></textarea>
                        </div>

                        <?php if($errors->any() && old('action') == 'edit'): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="submit" id="submitbtn" class="btn btn-primary">Simpan</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="viewModal" tabindex="-1" role="dialog" aria-labelledby="viewModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">View Transaksi</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    
                        <input type="hidden" name="action" value="view">
                        <div class="mb-3">
                            <label for="category-code-view" class="col-form-label">Kode Kategori :</label>
                            <select class="form-control" name="categorycodeview" id="category-code-view" disabled>
                                <option value="">PILIH KODE KATEGORI</option>
                                <?php $__currentLoopData = $codeCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row->tblitemcategory_id); ?>">
                                        <?php echo e($row->tblitemcategory_code); ?> -
                                        <?php echo e($row->tblitemcategory_name); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="brand-code-view" class="col-form-label">Kode Merek :</label>
                            <select class="form-control" name="brandcodeview" id="brand-code-view" disabled>
                                <option value="" >PILIH KODE MEREK</option>
                                <?php $__currentLoopData = $codeBrand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row->tblitembrand_id); ?>"><?php echo e($row->tblitembrand_code); ?> -
                                        <?php echo e($row->tblitembrand_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="model-code-view" class="col-form-label">Kode Model :</label>
                            <select class="form-control" name="modelcodeview" id="model-code-view" disabled>
                                <?php $__currentLoopData = $codeModel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->tblitemmodel_id); ?>"><?php echo e($row->tblitemmodel_codeModel); ?> -
                                    <?php echo e($row->tblitemmodel_descriptionModel); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="sn-transaction-view" class="col-form-label">SN :</label>
                            <input type="text" class="form-control" name="sntransactionview" id="sn-transaction-view" disabled>
                        </div>
                        <div class="mb-3">
                            <label for="dok-bukti-view" class="col-form-label">Dokumen Bukti :</label>
                            <input type="text" class="form-control" name="dokbuktiview" id="dok-bukti-view" disabled>
                        </div>
                        <div class="mb-3">
                            <label for="distributor-id-view" class="col-form-label">Distributor :</label>
                            <input type="text" class="form-control" name="distributornameview" id="distributor-id-view" disabled>
                        </div>
                        <div class="mb-3">
                            <label for="pemakai-id-view" class="col-form-label">Pemakai :</label>
                            <input type="text" class="form-control" name="pemakainameview" id="pemakai-id-view" disabled>
                        </div>
                        <div class="mb-3">
                            <label for="lokasi-id-view" class="col-form-label">Lokasi :</label>
                            <input type="text" class="form-control" name="lokasinameview" id="lokasi-id-view" disabled>
                        </div>
                        <div class="mb-3">
                            <label for="tanggal-beli-id-view" class="col-form-label">Tanggal Pembelian :</label>
                            <input type="date" class="form-control" name="tanggalbelinameview" id="tanggal-beli-id-view" disabled>
                        </div>
                        <div class="mb-3">
                            <label for="period-id-view" class="col-form-label">Periode Bulan :</label>
                            <input type="number" class="form-control" min="1" value="0" max="100" name="periodnameview"
                                id="period-id-view" disabled>
                        </div>
                        <div class="mb-3">
                            <label for="status-id-view" class="col-form-label">Status :</label>
                            <select class="form-control" name="statusname" id="status-id-view" disabled>
                                <?php $__currentLoopData = $codeStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row->tblitemstatus_id); ?>"><?php echo e($row->tblitemstatus_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="catatan-id-view" class="col-form-label">Catatan :</label>
                            <textarea class="form-control" name="noteview" id="model-note-view" disabled></textarea>
                        </div>

                        
                </div>
                <div class="modal-footer">
                    
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="createModal" tabindex="-1" role="dialog" aria-labelledby="createModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Transaksi</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="/transaction" method="POST" id="AddForm">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="action" value="create">
                    <div class="mb-3">
                        <label for="category-code" class="col-form-label">Kode Kategori :</label>
                        <select class="form-control" name="categorycode" id="category-code">
                            <option value="">PILIH KODE KATEGORI</option>
                            <?php $__currentLoopData = $codeCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->tblitemcategory_id); ?>">
                                    <?php echo e($row->tblitemcategory_code); ?> -
                                    <?php echo e($row->tblitemcategory_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="brand-code" class="col-form-label">Kode Merek :</label>
                        <select class="form-control" name="brandcode" id="brand-code">
                            <option value="">PILIH KODE MEREK</option>
                            <?php $__currentLoopData = $codeBrand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->tblitembrand_id); ?>"><?php echo e($row->tblitembrand_code); ?> -
                                    <?php echo e($row->tblitembrand_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="model-code" class="col-form-label">Kode Model :</label>
                        <select class="form-control" name="modelcode" id="model-code">
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="sn-transaction" class="col-form-label">SN :</label>
                        <input type="text" class="form-control" name="sntransaction" id="sn-transaction">
                    </div>
                    <div class="mb-3">
                        <label for="dok-bukti" class="col-form-label">Dokumen Bukti :</label>
                        <input type="text" class="form-control" name="dokbukti" id="dok-bukti">
                    </div>
                    <div class="mb-3">
                        <label for="distributor-id" class="col-form-label">Distributor :</label>
                        <input type="text" class="form-control" name="distributorname" id="distributor-id">
                    </div>
                    <div class="mb-3">
                        <label for="pemakai-id" class="col-form-label">Pemakai :</label>
                        <input type="text" class="form-control" name="pemakainame" id="pemakai-id">
                    </div>
                    <div class="mb-3">
                        <label for="lokasi-id" class="col-form-label">Lokasi :</label>
                        <input type="text" class="form-control" name="lokasiname" id="lokasi-id">
                    </div>
                    <div class="mb-3">
                        <label for="tanggal-beli-id" class="col-form-label">Tanggal Pembelian :</label>
                        <input type="date" class="form-control" name="tanggalbeliname" id="tanggal-beli-id">
                    </div>
                    <div class="mb-3">
                        <label for="period-id" class="col-form-label">Periode Bulan :</label>
                        <input type="number" class="form-control" min="1" value="0" max="100" name="periodname"
                            id="period-id">
                    </div>
                    <div class="mb-3">
                        <label for="status-id" class="col-form-label">Status :</label>
                        <select class="form-control" name="statusname" id="status-id">
                            <?php $__currentLoopData = $codeStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->tblitemstatus_id); ?>"><?php echo e($row->tblitemstatus_name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="catatan-id" class="col-form-label">Catatan :</label>
                        <textarea class="form-control" name="note" id="model-name-add" form="AddForm"></textarea>
                    </div>

                    <?php if($errors->any() && old('action') == 'create'): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
            </div>
            <div class="modal-footer">
                <button type="submit" id="submitbtn" class="btn btn-primary">Simpan</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                </form>
            </div>
        </div>
    </div>
</div>


    <script>
        <?php
        if (count($errors->all()) > 0 && old('action') == 'create') {
            echo "$('#createModal').modal('show');";
        }
        ?>
        <?php
        if (count($errors->all()) > 0 && old('action') == 'edit') {
            echo "$('#editModal').modal('show');";
        }
        ?>
        $(".buttonViewModel").click(function() {
            $('#model-code-view').val($(this).data('modelid')).change();
            $('#dok-bukti-view').val($(this).data('dokbukti'));
            $('#distributor-id-view').val($(this).data('distributor'));
            $('#sn-transaction-view').val($(this).data('sn'));
            $('#pemakai-id-view').val($(this).data('user'));
            $('#lokasi-id-view').val($(this).data('location'));
            $('#tanggal-beli-id-view').val($(this).data('purchasedate').substring(0,10));
            $('#period-id-view').val($(this).data('periodmonth'));
            $('#model-note-view').val($(this).data('note'));
            $('#status-id-view').val($(this).data('status'));
            var categorydetail = $(this).data('categorydetail');
            var branddetail = $(this).data('branddetail');
            var categoryCN = $(this).data('category');
            var brandCN = $(this).data('brand');
            $("#category-code-view").val(categorydetail).change();
            $("#brand-code-view").val(branddetail).change();
        });
        $(".buttonEditModel").click(function() {
            var url = "/transaction/edit/" + $(this).data('id');
            $("#EditForm").attr("action", url);
            $('#dok-bukti').val($(this).data('dokbukti'));
            $('#distributor-id').val($(this).data('distributor'));
            $('#sn-transaction').val($(this).data('sn'));
            $('#pemakai-id').val($(this).data('user'));
            $('#lokasi-id').val($(this).data('location'));
            $('#tanggal-beli-id').val($(this).data('purchasedate').substring(0,10));
            $('#period-id').val($(this).data('periodmonth'));
            $('#model-note').val($(this).data('note'));
            $('#status-id').val($(this).data('status'));
            var categorydetail = $(this).data('categorydetail');
            var branddetail = $(this).data('branddetail');
            var categoryCN = $(this).data('category');
            var brandCN = $(this).data('brand');
            $("#category-code-edit").val(categorydetail).change();
            $("#brand-code-edit").val(branddetail).change();
        });
        $('select[name="categorycode"]').on('change', function() {
            Nyoba(this, "cat");
            // console.log('Ini Add');
        });

        $('select[name="brandcode"]').on('change', function() {
            Nyoba(this, "brand");
            // console.log('Ini Add');
        });

        $('select[name="categorycodeedit"]').on('change', function() {
            NyobaEdit(this, "cat");
            // console.log('Ini Edit');
        });

        $('select[name="brandcodeedit"]').on('change', function() {
            NyobaEdit(this, "brand");
            // console.log('Ini Edit');
        });
    </script>
</body>

</html>
