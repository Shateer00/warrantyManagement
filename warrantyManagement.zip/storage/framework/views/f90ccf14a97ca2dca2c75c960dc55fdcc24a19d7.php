<?php $__env->startSection('content'); ?>
    <div class="pl-3 pt-4">
        <div class="row">
            <div class="pb-3 col-12 col-md-8">
                <button type="button" id="buttonAddCategory" class="btn btn-primary" data-toggle="modal"
                    data-target="#createModal" data-whatever="@mdo">Tambah Kategori Barang</button>
            </div>
            <div class="col-12 col-md-4">
                <form class="form-inline my-2 my-lg-0" action="<?php echo e(route('category.search')); ?>" method="get">
                    <?php if($requestParam == ''): ?>
                        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search"
                            name='param'>
                    <?php else: ?>
                        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search"
                            name='param' value="<?php echo e($requestParam); ?>">
                    <?php endif; ?>
                    <button class="btn btn-success my-2 my-sm-0" type="submit">Search</button>
                    <a class="btn btn-warning my-2 my-sm-0 ml-3" href="<?php echo e(route('category')); ?>">Reset</a>
                </form>
            </div>
        </div>

        <div class="col-12">
            <h3>List Kategori Barang</h3>
            <table class="table table-hovertable-responsive-sm">
                <thead>
                    <tr>
                        <th scope="col">
                            Nomor
                        </th>
                        
                        <th scope="col">
                            Kode Kategori
                        </th>
                        <th scope="col">
                            Nama Kategori
                        </th>
                        <th>
                            Sub Menu
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($category->firstItem() + $key); ?>

                            </td>
                            <td>
                                <?php echo e($row->tblitemcategory_code); ?>

                            </td>
                            <td>
                                <?php echo e($row->tblitemcategory_name); ?>

                            </td>
                            <td>
                                
                                    <a class="btn btn-primary" href="<?php echo e(route('category.edit', $row->tblitemcategory_id)); ?>">
                                        <p class="fas fa-edit"></p>
                                        <p class="btnEdit">Edit</p>
                                    </a>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <?php echo e($category->links()); ?>

        </div>

    </div>




    <div class="modal fade" id="createModal" tabindex="-1" role="dialog" aria-labelledby="createModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Tambah Kategori Barang</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('category.add')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                <div class="modal-body">

                        <div class="mb-3">
                            <label for="category-code" class="col-form-label">Kode Kategori :</label>
                            <input type="hidden" name="action" value="create">
                            <input type="text" class="form-control upperText" id="category-code" name="categorycode"
                                value="<?php echo e(old('categorycode')); ?>">

                        </div>
                        <div class="mb-3">
                            <label for="category-name" class="col-form-label">Nama Kategori :</label>

                            <input type="text" class="form-control" id="category-name" name="categoryname"
                                value="<?php echo e(old('categoryname')); ?>">


                        </div>
                        <?php if($errors->any() && old('action') == 'create'): ?>
                            <div class="alert alert-danger">
                                <ul>

                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="submit" id="submitbtn" class="btn btn-primary">Simpan</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>

                </div>
            </form>
            </div>
        </div>
    </div>

    <?php if(count($errors->all()) > 0 && old('action') == 'create'): ?>
        <script>
            ModalCreateShow();
        </script>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>